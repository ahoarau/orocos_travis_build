#!/bin/sh

export TYPELIB_USE_GCCXML=1

# Note: LD_LIBRARY_PATH/DYLD_LIBRARY_PATH will be set in 00.utilrb.sh.in.
