#!/bin/sh

export RUBYOPT=-rubygems

for path in "/root/orocos-2.9_ws/install/lib/ruby/1.9.1" "/root/orocos-2.9_ws/install/lib/ruby/1.9.1/x86_64-linux"; do
  if [ ! -d "$path" ]; then
    continue
  fi

  if [ -z "$RUBYLIB" ]; then
    RUBYLIB="$path"
  elif ! echo "$RUBYLIB" | grep -q "$path"; then
    RUBYLIB="$path:$RUBYLIB"
  fi
  export RUBYLIB

  if [ `uname -s` != Darwin ]; then
    if [ -z "$LD_LIBRARY_PATH" ]; then
      LD_LIBRARY_PATH="$path"
    elif ! echo "$LD_LIBRARY_PATH" | grep -q "$path"; then
      LD_LIBRARY_PATH="$path:$LD_LIBRARY_PATH"
    fi
    export LD_LIBRARY_PATH
  else
    if [ -z "$DYLD_LIBRARY_PATH" ]; then
      DYLD_LIBRARY_PATH="$path"
    elif ! echo "$DYLD_LIBRARY_PATH" | grep -q "$path"; then
      DYLD_LIBRARY_PATH="$path:$DYLD_LIBRARY_PATH"
    fi
    export DYLD_LIBRARY_PATH
  fi
done
