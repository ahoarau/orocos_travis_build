#warning including <%= typekit.name %>/Opaques.hpp is deprecated \
         If in typekit/Opaques.cpp, you should include <%= typekit.name %>/typekit/OpaqueTypes.hpp and <%= typekit.name %>/typekit/Opaques.hpp. \
         In doubt, see templates/typekit/Opaques.cpp.
#include <<%= typekit.name %>/typekit/Opaques.hpp>
#include <<%= typekit.name %>/typekit/OpaqueTypes.hpp>

