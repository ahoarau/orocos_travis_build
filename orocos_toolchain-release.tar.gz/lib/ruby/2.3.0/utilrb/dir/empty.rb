class Dir
    def empty?; entries.size == 2 end
end
