#ifndef ORO_RTT_plugin_FWD_HPP
#define ORO_RTT_plugin_FWD_HPP

namespace RTT {
    namespace plugin {
        class PluginLoader;
    }
    namespace detail {
        using namespace plugin;
    }
}
#endif
